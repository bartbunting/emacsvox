param([string]$Engine='eloquence')
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Emacsvox\AudioDeviceTests\transient-20261113'
$client=Join-Path $root 'client'
. (Join-Path $client 'utils\emacsvox-windows-common.ps1')
$config=[IO.File]::ReadAllText((Join-Path $client 'native-install.json')) | ConvertFrom-Json
$run=Join-Path $root ('logs\channels-' + $Engine + '-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ'))
New-Item -ItemType Directory -Path $run | Out-Null
Copy-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'Emacsvox\NativeLightweight\merge-check-20261113\probe-config\config.json') -Destination (Join-Path $run 'config.json')
$environment=@{
 EMACSVOX_DIR=$client; TTS_PROGRAM=$config.Omnivox; ESPEAK_NG_DATA=$config.EspeakData;
 OMNIVOX_CONFIG_DIR=$run; OMNIVOX_VOICE_ROOT=(Join-Path $run 'voices'); XDG_STATE_HOME=(Join-Path $run 'state');
 OMNIVOX_ENGINE=$Engine; OMNIVOX_AUDIO_OUTPUT='device'; OMNIVOX_AUDIO_DEVICE=$null;
 OMNIVOX_AUDIO_DEVICE_PREFERENCES=$null; OMNIVOX_OWNED_AUDIO_DEVICE=$null; OMNIVOX_OWNED_AUDIO_DEVICE_HOST=$null;
 OMNIVOX_EXPERIMENTAL_EARLY_SPEECH=$null; OMNIVOX_DEVICE_TEST_ROOT=$run; EMACSVOX_PLAY=$null;
}
Write-Output "Run: $run"
Invoke-EmacsvoxNative $config.Emacs @('-Q','--batch','--eval',(Get-EmacsvoxLoadExpression (Join-Path $root 'channel-check.el'))) $environment (Join-Path $run 'emacs.log') 360
Get-Content -LiteralPath (Join-Path $run 'result.json') -Raw
