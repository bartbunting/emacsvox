param([string]$Engine='eloquence')
$ErrorActionPreference='Stop'
$env:OMNIVOX_ENGINE=$Engine
& (Join-Path $env:LOCALAPPDATA 'Emacsvox\AudioDeviceTests\transient-20261113\evox-windows.ps1') -Check
