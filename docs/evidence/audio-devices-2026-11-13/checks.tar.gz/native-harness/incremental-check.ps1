$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Emacsvox\AudioDeviceTests\transient-20261113'
$client=Join-Path $root 'client'
. (Join-Path $client 'utils\emacsvox-windows-common.ps1')
$config=[IO.File]::ReadAllText((Join-Path $client 'native-install.json')) | ConvertFrom-Json
$environment=@{ EMACSVOX_DIR=$client; EMACSVOX_NATIVE_ROOT=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($client)); EMACSVOX_NATIVE_BYTECODE='check' }
Invoke-EmacsvoxNative $config.Emacs @('-Q','--batch','--eval',(Get-EmacsvoxLoadExpression (Join-Path $root 'incremental-check.el'))) $environment (Join-Path $root 'logs\bytecode-incremental-menu-final.log') 120
Invoke-EmacsvoxNative $config.Emacs @('-Q','--batch','--eval',(Get-EmacsvoxLoadExpression (Join-Path $client 'utils\emacsvox-native-bytecode.el')),'--funcall','emacsvox-native-bytecode-main') $environment (Join-Path $root 'logs\bytecode-check-menu-final.log') 120
Invoke-EmacsvoxNative $config.Emacs @('-Q','--batch','--eval',(Get-EmacsvoxLoadExpression (Join-Path $root 'compiled-device-tests.el'))) $environment (Join-Path $root 'logs\compiled-device-tests-menu-final.log') 120
